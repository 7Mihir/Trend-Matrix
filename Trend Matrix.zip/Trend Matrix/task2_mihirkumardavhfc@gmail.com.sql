--qQ.  Which interests have been present in all month_year dates in our dataset?

---solu

--checking the number of dates
select count(distinct month_year) as count
from interest_metrics 

--interests present  in all month_year dates
select distinct interest_id
from interest_metrics 
group by interest_id
having count(distinct month_year)=14

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------



--qQ.  Using this same total_months measure - calculate the cumulative percentage of all records starting at 14 months - which total_months value passes the 90% cumulative percentage value?

---solu
-- Calculate the count of unique month_year occurrences for each interest_id
with months_count as (
select distinct interest_id, count(month_year) as month_count
from interest_metrics 
group by interest_id
    --order by 2 desc 
),
-- Calculate the count of interest_ids for each month_count
interests_count as (
select month_count, count(interest_id) as interest_count
from months_count
group by month_count
),
-- Calculate the cumulative percentage of interest counts
cumulative_percentage as (
select *,
round(sum(interest_count) over(order by month_count desc) * 100.0 / (select sum(interest_count) from interests_count), 2) as cumulative_percent
from interests_count
group by month_count, interest_count
)
-- Select rows where cumulative_percentage is greater than 90
select *
from cumulative_percentage
where cumulative_percent > 90;

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---q  If we were to remove all interest_id values which are lower than the total_months value we found in the previous question - how many total data points would we be removing? 
--solu


--getting interest ids which have month count less than 6
with month_counts as
(
select interest_id, count(distinct month_year) as month_count
from 
interest_metrics
group by interest_id
having count(distinct month_year) <6 
)

--getting the number of times the above interest ids are present in the interest_metrics table
select count(interest_id) as interest_record_to_remove
from interest_metrics
where interest_id in (select interest_id from month_counts)


---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--q Does this decision make sense to remove these data points from a business perspective? Use an example where there are all 14 months present to a removed interest example for your arguments - think about what it means to have less months present from a segment perspective. 


----solu  

-----  (CTE) to calculate the month count for each interest
with month_counts as
(
    -- Count the number of distinct month_year values for each interest_id
select interest_id, count(distinct month_year) as month_count
from interest_metrics
group by interest_id
    
    having count(distinct month_year) < 6
)

-- Selecting removed month_year, present_interest, removed_interest, and removed_prcnt
select removed.month_year, present_interest, removed_interest,
round(removed_interest * 100.0 / (removed_interest + present_interest), 2) as removed_prcnt
from
(
select month_year, count(*) as removed_interest
from interest_metrics
where interest_id in (select interest_id from month_counts)
group by month_year
) removed

join 
(
select month_year, count(*) as present_interest
from interest_metrics
where interest_id not in (select interest_id from month_counts)
group by month_year
) present
-- Joining on month_year to combine the results
on removed.month_year = present.month_year
-- Ordering the results by month_year
order by removed.month_year;

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--q  After removing these interests - how many unique interests are there for each month?
--solu 

--  (CTE) to calculate the month count for each interest
with month_counts as
(
    -- Count the number of distinct month_year values for each interest_id
select interest_id, count(distinct month_year) as month_count
from interest_metrics
group by interest_id
having count(distinct month_year) < 6
)

-- Selecting month_year and the count of unique present interests for each month
select month_year, count(distinct interest_id) as unique_interest
from interest_metrics
where interest_id not in (select interest_id from month_counts)
-- Group by month_year to count unique present interests for each month
group by month_year
-- Order the results by month_year
order by 1;
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

