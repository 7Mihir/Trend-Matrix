--q(a)Update the interest_metrics table by modifying the month_year column to be a date data type with the start of the month
--solu


-- Drop the existing month_year column from the interest_metrics table
ALTER TABLE interest_metrics
DROP COLUMN month_year;

-- Add a new month_year column as a DATE type to the interest_metrics table
ALTER TABLE interest_metrics
ADD month_year DATE;

-- Update the values in the month_year column based on the _year and _month columns
UPDATE interest_metrics
SET month_year = DATEFROMPARTS(_year, _month, 1);




------------------------------------------------------------------------------------------------------------------------------------------	-----------------------------------------
--q	What is count of records in the interest_metrics for each month_year value sorted in chronological order (earliest to latest) with the null values appearing first?
--solu


-- Selecting the month_year and counting records for each group
SELECT 
month_year,
COUNT(*) AS record_count
FROM 
interest_metrics
-- Grouping the records by month_year
GROUP BY 
month_year
-- Sorting of groups
ORDER BY 
    -- Sorting of NULL values first
CASE WHEN month_year IS NULL THEN 0 ELSE 1 END,
    -- Sorting non-NULL values
month_year;

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--q What do you think we should do with these null values in the interest_metrics (You may impute nulls with appropriate value or Delete the records with Null values)

--solu


SELECT 
COUNT(month_year) AS record_counts
FROM interest_metrics
WHERE month_year IS NULL;
-- in this dealing with Nulls is delete those rows
DELETE FROM interest_metrics WHERE month_year IS NULL;

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--q  How many interest_id values exist in the interest_metrics table but not in the interest_map table? What about the other way around? 

---solu

----1. Interest_id values in Interest_metrics table but not in Interest_map table:

SELECT COUNT(DISTINCT im.interest_id) AS count_interest_metrics_only
FROM Interest_metrics im
-- Performing a LEFT JOIN to find records in Interest_metrics table that do not have corresponding records in Interest_map table
LEFT JOIN Interest_map imap ON im.interest_id = imap.id
-- Filtering the results that include only unmatched records from Interest_metrics table
WHERE imap.id IS NULL;


---2.Interest_id values in Interest_map table but not in Interest_metrics table:


SELECT COUNT(DISTINCT imap.id) AS count_interest_map_only
FROM Interest_map imap
-- Performing a LEFT JOIN to find records in Interest_map table that do not have corresponding records in Interest_metrics table
LEFT JOIN Interest_metrics im ON imap.id = im.interest_id
-- Filtering the results to include only unmatched records from Interest_map table
WHERE im.interest_id IS NULL;

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--q  Summarise the id values in the interest_map by its total record count in this table

--solu


-- Selecting id, interest_name, and count(*) as count from both tables
SELECT 
id, interest_name, COUNT(*) AS count
-- Joining the Interest_map table with the Interest_metrics table based on matching id and interest_id
FROM 
interest_map im 
JOIN 
interest_metrics met ON im.id = met.interest_id
-- Grouping the results by id and interest_name to count occurrences
GROUP BY 
id, interest_name
-- Sorting the results by the count in descending order
ORDER BY count DESC;



----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--q What sort of table join should we perform for our analysis and why? Join both tables and resultant table called as 'FullData' (15 Marks)

--Check your logic by checking the rows where interest_id = 21246 in your joined output and include all columns from interest_metrics and all columns from interest_map except from the id column.


-- Selecting specific columns from both the tables
SELECT 
_month, _year, interest_id, composition, index_value, ranking, percentile_ranking, -- Columns from Interest_metrics table
month_year, interest_name, interest_summary, created_at, last_modified -- Columns from Interest_map table
FROM 
interest_metrics met 
JOIN 
interest_map im ON met.interest_id = im.id
-- Filtering the rows where interest_id is equal to 21246
WHERE 
interest_id = 21246;


---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---q  Are there any records in your joined table where the month_year value is before the created_at value from the interest_map table? Do you think these values are valid and why? if these values are invalid, remove those records
---solu   Yes these records are valid because both the dates have the same month and we set the date for the month_year column to be the first day of the month


SELECT *-- Select all columns from the joined table where month_year is before created_at
FROM interest_metrics AS met
JOIN interest_map AS im ON met.interest_id = im.id 
WHERE CAST(met.month_year AS DATE) < CAST(im.created_at AS DATE);----- Checking if the month_year value is before the created_at value




