--q   Using our filtered dataset by removing the interests with less than 6 months worth of data, which are the top 10 and bottom 10 interests which have the largest composition values in any month_year? Only use the maximum composition value for each interest but you must keep the corresponding month_year 

--solu 

--(CTE) to identify interest_ids with month counts >= 6
WITH cte AS (
SELECT interest_id, COUNT(DISTINCT month_year) AS month_count
FROM interest_metrics
GROUP BY interest_id
HAVING COUNT(DISTINCT month_year) >= 6
)

SELECT * INTO filtered_table
FROM interest_metrics
WHERE interest_id IN (SELECT interest_id FROM cte);

-- the contents of the filtered_table
SELECT * FROM filtered_table;

-- the top 10 interests based on maximum composition
SELECT TOP 10  
month_year,
interest_id,
interest_name,
MAX(composition) AS max_composition
FROM filtered_table f
JOIN interest_map ma ON f.interest_id = ma.id
GROUP BY month_year, interest_id, interest_name
ORDER BY 4 DESC;

--  bottom 10 interests based on maximum composition
SELECT TOP 10
month_year,
interest_id,
interest_name,
MAX(composition) AS max_composition
FROM filtered_table f
JOIN interest_map ma ON f.interest_id = ma.id
GROUP BY month_year, interest_id, interest_name
ORDER BY 4 ASC;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

---q  Which 5 interests had the lowest average ranking value?

---solu

-- Selecting the top 5 interests with the lowest average ranking
SELECT TOP 5
    interest_id,
    interest_name,
    AVG(ranking) AS avg_ranking
FROM filtered_table f
JOIN interest_map ma ON f.interest_id = ma.id
GROUP BY interest_id, interest_name
-- Sorting the results in ascending order of average ranking
ORDER BY avg_ranking ASC;

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---q  Which 5 interests had the largest standard deviation in their percentile_ranking value?

---solu 

-- Selecting the top 5 interests with the highest standard deviation of percentile_ranking
SELECT TOP 5
interest_id,
interest_name,
ROUND(STDEV(percentile_ranking), 2) AS stdev_ranking
FROM filtered_table f
JOIN interest_map ma ON f.interest_id = ma.id
-- Grouping the results by interest_id and interest_name 
GROUP BY interest_id, interest_name
-- Sorting the results 
ORDER BY stdev_ranking DESC;


-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

---q  For the 5 interests found in the previous question - what was minimum and maximum percentile_ranking values for each interest and its corresponding year_month value? Can you describe what is happening for these 5 interests?

--solu we can determine the range of percentile_ranking values for each of the top 5 interests identified based on their largest standard deviations. This information provides insights into the variability of the ranking values over time for these interests.

-- CTE to retrieve the top 5 interests with the largest standard deviation
WITH interests AS (
SELECT TOP 5
interest_id,
interest_name,
ROUND(STDEV(percentile_ranking), 2) AS stdev_ranking
FROM filtered_table f
JOIN interest_map ma ON f.interest_id = ma.id
GROUP BY interest_id, interest_name
ORDER BY stdev_ranking DESC
),
-- CTE to find the maximum and minimum percentiles
percentiles AS (
SELECT
i.interest_id,
interest_name,
MAX(percentile_ranking) AS max_percentile,
MIN(percentile_ranking) AS min_percentile
FROM filtered_table f
JOIN interests i ON i.interest_id = f.interest_id
GROUP BY i.interest_id, interest_name
),
-- CTE to find the maximum percentiles and corresponding years
max_per AS (
SELECT
p.interest_id,
interest_name,
month_year AS max_year,
max_percentile
FROM filtered_table f
JOIN percentiles p ON p.interest_id = f.interest_id
WHERE max_percentile = percentile_ranking
),
-- CTE to find the minimum percentiles and corresponding years
min_per AS (
SELECT
p.interest_id,
interest_name,
month_year AS min_year,
min_percentile
FROM filtered_table f
JOIN percentiles p ON p.interest_id = f.interest_id
WHERE min_percentile = percentile_ranking
)
SELECT
 mi.interest_id, mi.interest_name,min_year,min_percentile,max_year,max_percentile
FROM min_per mi
JOIN max_per ma ON mi.interest_id = ma.interest_id;
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---q . How would you describe our customers in this segment based off their composition and ranking values? What sort of products or services should we show to these customers and what should we avoid? 


------solu

 /*Based on our analysis of the data, we've identified some key characteristics of our customers in this segment:

Composition Values: These values tell us how many customers are interested in specific products or services. Higher composition values mean that a larger portion of our customers are engaging with those interests.
Ranking Values: Ranking values give us an idea of how well-received or popular these interests are among our customers. Lower ranking values indicate higher levels of engagement or interest.


Products or Services to Show:
Diverse Offerings: Offer a variety of products or services that cater to the diverse interests represented in the segment. This way, we can provide options that match different customer preferences.
Trending or Emerging Interests: Keep an eye on interests with increasing composition values over time. These could be emerging trends, and promoting products or services related to them could attract early adopters or trend followers.

Products or Services to Avoid:
Irrelevant Offerings: Make sure not to offer products or services that don't match the identified interests of our customers. It's important to focus on what's relevant to them to keep them engaged.
Overlapping Interests: Be careful not to offer similar products or services related to interests that already have established offerings. Instead, we should focus on providing unique offerings or find ways to differentiate existing ones./*