----Average composition can be calculated by dividing the composition column by the index_value column rounded to 2 decimal places.


SELECT * FROM interest_metrics;

--  (CTE) to calculate the average composition and store it in a new column
WITH cte AS (
SELECT *, ROUND(composition / index_value, 2) AS avg_composition -- Calculate average composition and round to 2 decimal places
FROM interest_metrics 
)

SELECT * INTO index_table FROM cte;
--------------------------------------------------------------------------------------------------------------------------------------------------------------

--q   What is the top 10 interests by the average composition for each month?  

---solu   

--  (CTE) to calculate ranks for interests based on average composition for each month
WITH ranks_tab AS (
SELECT 
interest_id,
interest_name,
month_year,
avg_composition,
RANK() OVER (PARTITION BY month_year ORDER BY avg_composition DESC) AS ranks 
FROM 
index_table 
JOIN 
interest_map  ON interest_id = id
)

-- Selecting all columns from the ranks_tab 
SELECT 
* 
FROM 
ranks_tab 
WHERE 
ranks <= 10;

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--q For all of these top 10 interests - which interest appears the most often?   

---solu 
-- (CTE) to calculate ranks for interests based on average composition for each month
WITH ranks_tab AS (
SELECT 
interest_id,
interest_name,
month_year,
avg_composition,
RANK() OVER (PARTITION BY month_year ORDER BY avg_composition DESC) AS ranks 
FROM 
index_table 
JOIN 
interest_map  ON interest_id = id
)

SELECT 
DISTINCT interest_id,
interest_name,
COUNT(*) OVER (PARTITION BY interest_name) AS counts
FROM 
ranks_tab 
WHERE 
ranks <= 10 
ORDER BY 3 DESC; -- Order by the count of appearances in descending order
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

----q What is the average of the average composition for the top 10 interests for each month?

---solu 

--  (CTE) to calculate ranks for interests based on average composition for each month
WITH ranks_tab AS (
SELECT 
i.interest_id,
interest_name,
month_year,
avg_composition,
RANK() OVER (PARTITION BY month_year ORDER BY avg_composition DESC) AS ranks 
FROM 
index_table i
JOIN 
interest_map m ON i.interest_id = m.id
)
--- calculate the average monthly composition
SELECT 
month_year,
ROUND(AVG(avg_composition), 2) AS avg_monthly_comp
FROM 
ranks_tab 
WHERE 
ranks <= 10
GROUP BY 
month_year; -- Group by month_year to calculate the average monthly composition

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

---q What is the 3 month rolling average of the max average composition value from September 2018 to August 2019 and include the previous top ranking interests in the same output shown below

---solu 

--  (CTE) to find the maximum average composition for each month
WITH month_com AS (
SELECT  
month_year,
ROUND(MAX(avg_composition), 2) AS max_avg_com 
FROM 
index_table
GROUP BY 
month_year
), 
-- CTE to calculate rolling averages for interests with maximum average composition for 3 months
rolling_avg AS (
SELECT 
i.month_year,
interest_id,
interest_name,
max_avg_com AS max_index_composition, 
ROUND(AVG(max_avg_com) OVER (ORDER BY i.month_year ROWS BETWEEN 2 PRECEDING AND CURRENT ROW), 2) AS '3_month_moving_avg' -- Calculate 3-month moving average
FROM 
index_table i 
JOIN 
month_com m ON i.month_year = m.month_year
JOIN 
interest_map ma ON i.interest_id = ma.id
WHERE 
avg_composition = max_avg_com
),
-- CTE to calculate lagged values for 1 month ago
month_1_lag AS (
SELECT 
*,
CONCAT(LAG(interest_name) OVER (ORDER BY month_year), ' : ', LAG(max_index_composition) OVER (ORDER BY month_year)) AS [1_month_ago] -- Concatenate lagged values for 1 month ago
FROM 
rolling_avg
),
-- CTE to calculate lagged values for 2 months ago
month_2_lag AS (
SELECT 
 *,
 LAG([1_month_ago]) OVER (ORDER BY month_year) AS [2_month_ago] 
 FROM  
 month_1_lag
)
--  query to select data within a specified date range
SELECT 
    * 
FROM 
month_2_lag
WHERE 
month_year BETWEEN '2018-09-01' AND '2019-08-01'; 

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--q  Provide a possible reason why the max average composition might change from month to month? Could it signal something is not quite right with the overall business model for Fresh Segments? 

/* solu : The top interest can change every month because people's tastes and interests can vary. For example, during holidays, 
they might be more interested in certain things. If this keeps changing a lot, 
it could mean there's a problem with how the company is doing things. 
They might need to look at their ads and products to see what's not working and try to fix it to keep growing./*






